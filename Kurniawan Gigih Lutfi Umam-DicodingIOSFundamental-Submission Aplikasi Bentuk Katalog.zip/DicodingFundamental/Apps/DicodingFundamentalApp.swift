//
//  DicodingFundamentalApp.swift
//  DicodingFundamental
//
//  Created by Kurniawan Gigih Lutfi Umam on 06/08/21.
//

import SwiftUI

@main
struct DicodingFundamentalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
